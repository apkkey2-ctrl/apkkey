# KACU KEY

Suba esta pasta (ou o zip) no GitHub. O serviço (Render / Hugging Face / etc.) atualiza sozinho.

Painel: /painel-x7k9
Senha do painel: variável de ambiente ADMIN_PASSWORD

Na aba App:
- cole o link do MediaFire e clique em Salvar e publicar (o campo volta preenchido)
- adicione nome + URL da foto + link de cada app para aparecer na página de pegar Key
