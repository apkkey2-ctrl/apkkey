import os
import json
import sqlite3
import secrets
import string
from datetime import datetime, timedelta
import urllib.request
from flask import Flask, request, jsonify, render_template, redirect, session, g, Response, send_from_directory

app = Flask(__name__)


@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    return response


@app.route("/api/<path:_any>", methods=["OPTIONS"])
def cors_preflight(_any):
    return "", 204


ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "Troque#Esta1Senha")
app.secret_key = os.environ.get("SECRET_KEY", secrets.token_hex(16))

KEY_LENGTH_FREE = 10
KEY_LENGTH_VIP = 24
KEY_TTL_HOURS = 1
DB_PATH = os.path.join(os.path.dirname(__file__), "keys.db")

SOCIAL_LINKS = {
    "instagram": "https://www.instagram.com/rp_cris47",
    "whatsapp": "https://whatsapp.com/channel/0029VbCpyfeEgGfHP3DNvl1e",
    "telegram": "https://t.me/ggfpanel",
    "youtube": "https://www.youtube.com/@KACU_PANEL",
}

SITE_NAME = "KACU KEY"
DEFAULT_APK_URL = "https://huggingface.co/chrislot2025/app/resolve/main/apk.apk"
DEFAULT_APK_LINKS = [
    "https://huggingface.co/chrislot2025/app/resolve/main/apk1.apk",
    "https://huggingface.co/chrislot2025/app/resolve/main/apk.2apk",
    "https://huggingface.co/chrislot2025/app/resolve/main/apk.apk",
    "",
    "",
]
STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")
os.makedirs(STATIC_DIR, exist_ok=True)
MAX_APKS = 5


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS keys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            tier TEXT NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS vip_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            code TEXT,
            created_at TEXT NOT NULL
        )
    """)
    cols = {row[1] for row in conn.execute("PRAGMA table_info(vip_requests)").fetchall()}
    if "payment_method" not in cols:
        conn.execute("ALTER TABLE vip_requests ADD COLUMN payment_method TEXT")
    if "notes" not in cols:
        conn.execute("ALTER TABLE vip_requests ADD COLUMN notes TEXT")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS id_shares (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            share_code TEXT UNIQUE NOT NULL,
            sender_device TEXT,
            items_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


def get_setting(key, default=""):
    db = get_db()
    row = db.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(key, value):
    db = get_db()
    db.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )
    db.commit()


def get_apps():
    raw = get_setting("apps_json", "[]")
    try:
        data = json.loads(raw)
        if isinstance(data, list):
            return data
    except json.JSONDecodeError:
        pass
    return []


def empty_slot(i):
    return {
        "id": str(i + 1),
        "name": "",
        "version": "",
        "description": "",
        "link": DEFAULT_APK_LINKS[i] if i < len(DEFAULT_APK_LINKS) else "",
        "icon": "",
        "published": False,
    }


def get_apk_slots():
    raw = get_setting("apk_slots_json", "")
    slots = []
    if raw:
        try:
            data = json.loads(raw)
            if isinstance(data, list):
                slots = data
        except json.JSONDecodeError:
            slots = []
    while len(slots) < MAX_APKS:
        slots.append(empty_slot(len(slots)))
    slots = slots[:MAX_APKS]
    for i, s in enumerate(slots):
        s["id"] = str(i + 1)
        if not s.get("link"):
            s["link"] = DEFAULT_APK_LINKS[i]
    # migra o APK antigo (1 só) para o primeiro slot, se os slots ainda estiverem vazios
    if not any(s.get("name") or s.get("published") for s in slots):
        old_name = get_setting("apk_name")
        if old_name or get_setting("apk_published") == "1":
            slots[0]["name"] = old_name or "KACU"
            slots[0]["version"] = get_setting("apk_version") or "1.0"
            slots[0]["description"] = get_setting("apk_description")
            slots[0]["link"] = get_setting("apk_link") or DEFAULT_APK_LINKS[0]
            slots[0]["icon"] = get_setting("apk_icon")
            slots[0]["published"] = get_setting("apk_published", "1") != "0"
    return slots


def save_apk_slots(slots):
    set_setting("apk_slots_json", json.dumps(slots[:MAX_APKS], ensure_ascii=False))


def generate_code(tier):
    alphabet = string.ascii_uppercase + string.digits
    length = KEY_LENGTH_VIP if tier == "vip" else KEY_LENGTH_FREE
    body = "".join(secrets.choice(alphabet) for _ in range(length))
    prefix = "VIP-" if tier == "vip" else "FREE-"
    return prefix + body


def utcnow():
    return datetime.utcnow().replace(microsecond=0)


def parse_dt(value):
    if not value:
        return None
    text = str(value).strip().replace("Z", "")
    if "." in text:
        text = text.split(".", 1)[0]
    try:
        return datetime.fromisoformat(text)
    except ValueError:
        return None


def stamp(dt=None):
    return (dt or utcnow()).strftime("%Y-%m-%dT%H:%M:%S")


SHARE_TTL_MINUTES = 30


def cleanup_expired_keys():
    """Marca como inativa. Não apaga sozinha, para o painel não 'sumir' com senha ativa."""
    db = get_db()
    now = stamp()
    db.execute("UPDATE keys SET active = 0 WHERE expires_at < ? AND active = 1", (now,))
    db.execute("DELETE FROM id_shares WHERE expires_at < ?", (now,))
    db.commit()


def create_key(tier):
    db = get_db()
    code = generate_code(tier)
    now = utcnow()
    expires = now + timedelta(hours=KEY_TTL_HOURS)
    db.execute(
        "INSERT INTO keys (code, tier, created_at, expires_at, active) VALUES (?, ?, ?, ?, 1)",
        (code, tier, stamp(now), stamp(expires)),
    )
    db.commit()
    return code, expires


@app.route("/")
def home():
    return render_template(
        "index.html",
        links=SOCIAL_LINKS,
        support_email=get_setting("support_email"),
        apps=get_apps(),
        site_name=SITE_NAME,
    )


@app.route("/termos")
def termos():
    return render_template(
        "termos.html",
        support_email=get_setting("support_email"),
        site_name=SITE_NAME,
    )


@app.route("/vip")
def vip_page():
    return render_template(
        "vip.html",
        telegram=SOCIAL_LINKS["telegram"],
        support_email=get_setting("support_email"),
        site_name=SITE_NAME,
    )


@app.route("/apk")
@app.route("/APK")
def apk_page():
    slots = [s for s in get_apk_slots() if s.get("published") and s.get("name")]
    return render_template(
        "apk.html",
        slots=slots,
        site_name=SITE_NAME,
    )


def stream_apk(url, filename):
    req = urllib.request.Request(url, headers={"User-Agent": "KACU-KEY-Download"})
    remote = urllib.request.urlopen(req, timeout=90)
    length = remote.headers.get("Content-Length")

    def generate():
        try:
            while True:
                chunk = remote.read(64 * 1024)
                if not chunk:
                    break
                yield chunk
        finally:
            remote.close()

    headers = {
        "Content-Disposition": 'attachment; filename="%s"' % filename,
        "Content-Type": "application/vnd.android.package-archive",
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff",
    }
    if length:
        headers["Content-Length"] = length
    return Response(generate(), headers=headers)


@app.route("/apk/download")
@app.route("/APK/download")
def apk_download_default():
    slots = [s for s in get_apk_slots() if s.get("published") and (s.get("link") or s.get("name"))]
    if not slots:
        return "Nenhuma atualização publicada.", 404
    slot = slots[0]
    url = slot.get("link") or DEFAULT_APK_URL
    filename = (slot.get("name") or "KACU").replace(" ", "_") + ".apk"
    try:
        return stream_apk(url, filename)
    except Exception:
        return "Arquivo indisponível no momento.", 502


@app.route("/apk/download/<slot_id>")
@app.route("/APK/download/<slot_id>")
def apk_download_slot(slot_id):
    slots = get_apk_slots()
    slot = next((s for s in slots if s.get("id") == str(slot_id)), None)
    if not slot or not slot.get("published"):
        return "App não publicado.", 404
    url = slot.get("link") or DEFAULT_APK_URL
    filename = (slot.get("name") or ("app" + str(slot_id))).replace(" ", "_") + ".apk"
    try:
        return stream_apk(url, filename)
    except Exception:
        return "Arquivo indisponível no momento.", 502


@app.route("/api/id", methods=["GET"])
@app.route("/api/ids", methods=["GET"])
def api_id_info():
    return jsonify({
        "success": True,
        "api": "ID",
        "name": "KACU ID",
        "public": True,
        "apiKey": False,
        "expiresInMinutes": SHARE_TTL_MINUTES,
        "send": "POST /api/id/share",
        "receive": "GET /api/id/share/CODIGO",
    })


@app.route("/api/id/share", methods=["POST"])
@app.route("/api/ids/share", methods=["POST"])
def api_ids_share_create():
    """Segundo app: publica um pacote de IDs com código curto, válido por 30 min."""
    cleanup_expired_keys()
    data = request.get_json(silent=True) or {}
    share_code = (data.get("shareCode") or data.get("code") or "").strip().upper()
    if not share_code or len(share_code) > 16 or not share_code.replace("-", "").isalnum():
        return jsonify({"success": False, "message": "shareCode inválido."}), 400

    items = data.get("items") or []
    if not isinstance(items, list) or not items:
        return jsonify({"success": False, "message": "Envie a lista items."}), 400
    if len(items) > 200:
        return jsonify({"success": False, "message": "Máximo de 200 itens por código."}), 400

    clean = []
    for item in items:
        if not isinstance(item, dict):
            continue
        clean.append({
            "id": item.get("id"),
            "name": str(item.get("name") or "")[:120],
            "gameId": str(item.get("gameId") or "")[:64],
            "category": str(item.get("category") or "")[:40],
            "isFavorite": bool(item.get("isFavorite")),
        })
    if not clean:
        return jsonify({"success": False, "message": "Nenhum item válido."}), 400

    sender = str(data.get("senderDevice") or "")[:80]
    now = utcnow()
    expires = now + timedelta(minutes=SHARE_TTL_MINUTES)
    db = get_db()
    db.execute(
        "INSERT INTO id_shares (share_code, sender_device, items_json, created_at, expires_at) "
        "VALUES (?, ?, ?, ?, ?) "
        "ON CONFLICT(share_code) DO UPDATE SET "
        "sender_device = excluded.sender_device, items_json = excluded.items_json, "
        "created_at = excluded.created_at, expires_at = excluded.expires_at",
        (share_code, sender, json.dumps(clean, ensure_ascii=False), stamp(now), stamp(expires)),
    )
    db.commit()
    return jsonify({
        "success": True,
        "shareCode": share_code,
        "message": "IDs publicados com sucesso!",
        "expiresInMinutes": SHARE_TTL_MINUTES,
        "totalItems": len(clean),
    }), 201


@app.route("/api/id/share/<share_code>", methods=["GET"])
@app.route("/api/ids/share/<share_code>", methods=["GET"])
def api_ids_share_get(share_code):
    cleanup_expired_keys()
    code = (share_code or "").strip().upper()
    db = get_db()
    row = db.execute("SELECT * FROM id_shares WHERE share_code = ?", (code,)).fetchone()
    if row is None:
        return jsonify({"success": False, "message": "Código expirado ou não encontrado."}), 404
    expires_at = parse_dt(row["expires_at"])
    if expires_at is None or utcnow() > expires_at:
        db.execute("DELETE FROM id_shares WHERE id = ?", (row["id"],))
        db.commit()
        return jsonify({"success": False, "message": "Código expirado ou não encontrado."}), 404
    try:
        items = json.loads(row["items_json"] or "[]")
    except json.JSONDecodeError:
        items = []
    return jsonify({
        "success": True,
        "shareCode": row["share_code"],
        "senderDevice": row["sender_device"] or "",
        "totalItems": len(items),
        "items": items,
        "expiresAt": row["expires_at"] + "Z",
    })


@app.route("/api/generate-free", methods=["POST"])
def api_generate_free():
    cleanup_expired_keys()
    code, expires = create_key("free")
    return jsonify({"code": code, "tier": "free", "expires_at": expires.isoformat() + "Z"})


@app.route("/api/generate-vip", methods=["POST"])
def api_generate_vip():
    cleanup_expired_keys()
    data = request.get_json(silent=True) or {}
    full_name = (data.get("full_name") or request.form.get("full_name") or "").strip()
    email = (data.get("email") or request.form.get("email") or "").strip()
    phone = (data.get("phone") or request.form.get("phone") or "").strip()
    payment_method = (data.get("payment_method") or request.form.get("payment_method") or "").strip()
    notes = (data.get("notes") or request.form.get("notes") or "").strip()

    if not full_name or not email or not phone:
        return jsonify({"error": "Preencha nome completo, e-mail e número."}), 400
    if "@" not in email or "." not in email:
        return jsonify({"error": "E-mail inválido."}), 400

    code, expires = create_key("vip")
    db = get_db()
    db.execute(
        "INSERT INTO vip_requests (full_name, email, phone, code, created_at, payment_method, notes) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (full_name, email, phone, code, datetime.utcnow().isoformat(), payment_method, notes),
    )
    db.commit()
    return jsonify({
        "code": code,
        "tier": "vip",
        "expires_at": expires.isoformat() + "Z",
    })


def build_notification_payload():
    raw_id = get_setting("notification_id", "0")
    try:
        nid = int(raw_id)
    except ValueError:
        nid = 0
    message = get_setting("notification_message", "")
    sent_at = get_setting("notification_sent_at", "")
    title = get_setting("notification_title", "KACU KEY")
    item = {
        "id": nid,
        "title": title,
        "message": message,
        "text": message,
        "body": message,
        "content": message,
        "sent_at": sent_at,
        "timestamp": sent_at,
        "created_at": sent_at,
    }
    return {
        "ok": True,
        "success": True,
        "active": bool(message),
        "id": nid,
        "notification_id": nid,
        "title": title,
        "message": message,
        "text": message,
        "body": message,
        "content": message,
        "sent_at": sent_at,
        "timestamp": sent_at,
        "created_at": sent_at,
        "notification": item,
        "data": item,
        "notifications": [item] if message else [],
    }


@app.route("/api/notification", methods=["GET", "POST"])
@app.route("/api/notifications", methods=["GET", "POST"])
@app.route("/api/notify", methods=["GET", "POST"])
def api_notification():
    resp = jsonify(build_notification_payload())
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    return resp


@app.route("/api/validate", methods=["POST"])
def api_validate():
    data = request.get_json(silent=True) or {}
    code = (data.get("code") or "").strip().upper()

    if not code:
        return jsonify({"valid": False, "reason": "Nenhuma senha enviada."}), 400

    db = get_db()
    row = db.execute("SELECT * FROM keys WHERE code = ?", (code,)).fetchone()

    if row is None:
        return jsonify({"valid": False, "reason": "Senha não encontrada."}), 404
    if not row["active"]:
        return jsonify({"valid": False, "reason": "Senha desativada."}), 403

    expires_at = parse_dt(row["expires_at"])
    if expires_at is None or utcnow() > expires_at:
        db.execute("DELETE FROM keys WHERE id = ?", (row["id"],))
        db.commit()
        return jsonify({"valid": False, "reason": "Senha expirada."}), 403

    return jsonify({
        "valid": True,
        "tier": row["tier"],
        "expires_at": row["expires_at"] + "Z",
    })


def list_id_shares():
    cleanup_expired_keys()
    db = get_db()
    now = utcnow()
    rows = db.execute("SELECT * FROM id_shares ORDER BY id DESC LIMIT 40").fetchall()
    out = []
    for r in rows:
        expires_at = parse_dt(r["expires_at"]) or now
        try:
            items = json.loads(r["items_json"] or "[]")
        except json.JSONDecodeError:
            items = []
        out.append({
            "id": r["id"],
            "share_code": r["share_code"],
            "sender_device": r["sender_device"] or "",
            "total": len(items),
            "created_at": r["created_at"],
            "expires_at": r["expires_at"],
            "left": max(0, int((expires_at - now).total_seconds())),
            "items": items,
        })
    return out


@app.route("/painel-x7k9", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        senha = request.form.get("senha", "")
        if senha == ADMIN_PASSWORD:
            session["admin"] = True
            return redirect("/painel-x7k9/dashboard")
        return render_template("admin_login.html", erro="Senha incorreta.", site_name=SITE_NAME)
    return render_template("admin_login.html", erro=None, site_name=SITE_NAME)


@app.route("/painel-x7k9/dashboard")
def admin_dashboard():
    if not session.get("admin"):
        return redirect("/painel-x7k9")

    cleanup_expired_keys()
    db = get_db()
    now = utcnow()
    now_s = stamp(now)
    rows = db.execute("SELECT * FROM keys ORDER BY id DESC").fetchall()
    keys = []
    for r in rows:
        expires_at = parse_dt(r["expires_at"]) or now
        still_valid = bool(r["active"]) and expires_at > now
        left = max(0, int((expires_at - now).total_seconds())) if still_valid else 0
        keys.append({
            "id": r["id"],
            "code": r["code"],
            "tier": r["tier"],
            "created_at": r["created_at"],
            "expires_at": r["expires_at"],
            "active": still_valid,
            "expired": expires_at <= now,
            "left": left,
        })

    vip_rows = db.execute("SELECT * FROM vip_requests ORDER BY id DESC LIMIT 50").fetchall()
    vip_requests = [dict(v) for v in vip_rows]
    # Contagem direta no banco, igual à regra de "ainda vale"
    active_count = db.execute(
        "SELECT COUNT(*) AS n FROM keys WHERE active = 1 AND expires_at > ?",
        (now_s,),
    ).fetchone()["n"]
    active_free = db.execute(
        "SELECT COUNT(*) AS n FROM keys WHERE active = 1 AND tier = 'free' AND expires_at > ?",
        (now_s,),
    ).fetchone()["n"]
    active_vip = db.execute(
        "SELECT COUNT(*) AS n FROM keys WHERE active = 1 AND tier = 'vip' AND expires_at > ?",
        (now_s,),
    ).fetchone()["n"]

    return render_template(
        "admin_dashboard.html",
        keys=keys,
        active_count=active_count,
        active_free=active_free,
        active_vip=active_vip,
        support_email=get_setting("support_email"),
        apk_slots=get_apk_slots(),
        apps=get_apps(),
        notification_message=get_setting("notification_message"),
        notification_title=get_setting("notification_title", "KACU KEY"),
        notification_sent_at=get_setting("notification_sent_at"),
        vip_requests=vip_requests,
        id_shares=list_id_shares(),
        site_name=SITE_NAME,
    )


@app.route("/painel-x7k9/salvar-suporte", methods=["POST"])
def admin_salvar_suporte():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    email = request.form.get("support_email", "").strip()
    set_setting("support_email", email)
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/publicar-apk", methods=["POST"])
def admin_publicar_apk():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    slots = get_apk_slots()
    names = request.form.getlist("slot_name")
    versions = request.form.getlist("slot_version")
    descriptions = request.form.getlist("slot_description")
    links = request.form.getlist("slot_link")
    published_ids = set(request.form.getlist("slot_published"))
    for i in range(MAX_APKS):
        slot = slots[i]
        slot["name"] = (names[i] if i < len(names) else "").strip()
        slot["version"] = (versions[i] if i < len(versions) else "").strip()
        slot["description"] = (descriptions[i] if i < len(descriptions) else "").strip()
        incoming = (links[i] if i < len(links) else "").strip()
        slot["link"] = incoming or DEFAULT_APK_LINKS[i]
        slot["published"] = str(i + 1) in published_ids and bool(slot["name"])
        field = "slot_icon_%s" % (i + 1)
        icon = request.files.get(field)
        if icon and icon.filename:
            ext = os.path.splitext(icon.filename)[1].lower()
            if ext not in {".png", ".jpg", ".jpeg", ".webp", ".gif"}:
                ext = ".png"
            fname = "app_icon_%s%s" % (i + 1, ext)
            icon.save(os.path.join(STATIC_DIR, fname))
            slot["icon"] = "/static/%s?v=%s" % (fname, stamp())
    save_apk_slots(slots)
    return redirect("/painel-x7k9/dashboard#app")


@app.route("/painel-x7k9/salvar-apps", methods=["POST"])
def admin_salvar_apps():
    if not session.get("admin"):
        return redirect("/painel-x7k9")

    names = request.form.getlist("app_name")
    images = request.form.getlist("app_image")
    links = request.form.getlist("app_link")
    apps = []
    for name, image, link in zip(names, images, links):
        name = (name or "").strip()
        image = (image or "").strip()
        link = (link or "").strip()
        if name or image or link:
            apps.append({"name": name, "image": image, "link": link})
    set_setting("apps_json", json.dumps(apps, ensure_ascii=False))
    return redirect("/painel-x7k9/dashboard#app")


@app.route("/painel-x7k9/gerar-vip", methods=["POST"])
def admin_gerar_vip():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    create_key("vip")
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/desativar/<int:key_id>", methods=["POST"])
def admin_desativar(key_id):
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    db = get_db()
    db.execute("UPDATE keys SET active = 0 WHERE id = ?", (key_id,))
    db.commit()
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/apagar/<int:key_id>", methods=["POST"])
def admin_apagar(key_id):
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    db = get_db()
    db.execute("DELETE FROM keys WHERE id = ?", (key_id,))
    db.commit()
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/limpar-expiradas", methods=["POST"])
def admin_limpar_expiradas():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    cleanup_expired_keys()
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/enviar-notificacao", methods=["POST"])
def admin_enviar_notificacao():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    mensagem = request.form.get("mensagem", "").strip()
    titulo = request.form.get("titulo", "").strip() or "KACU KEY"
    if mensagem:
        novo_id = int(get_setting("notification_id", "0") or "0") + 1
        set_setting("notification_id", str(novo_id))
        set_setting("notification_title", titulo)
        set_setting("notification_message", mensagem)
        set_setting("notification_sent_at", datetime.utcnow().isoformat() + "Z")
    return redirect("/painel-x7k9/dashboard#notificacao")


@app.route("/painel-x7k9/apagar-share/<int:share_id>", methods=["POST"])
def admin_apagar_share(share_id):
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    db = get_db()
    db.execute("DELETE FROM id_shares WHERE id = ?", (share_id,))
    db.commit()
    return redirect("/painel-x7k9/dashboard#ids")


@app.route("/painel-x7k9/sair")
def admin_logout():
    session.pop("admin", None)
    return redirect("/painel-x7k9")


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 7860)))
else:
    init_db()
