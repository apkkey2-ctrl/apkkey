# -*- coding: utf-8 -*-
"""
KACU KEY - Servidor completo
- Senhas FREE / VIP
- Página APK (download com barra)
- API ID (compartilhar códigos QR)
- Notificações
- API XNX LOJA (GET /api/apks + POST /api/vendas)
"""
from flask import (
    Flask, request, jsonify, render_template, redirect,
    url_for, session, send_from_directory, Response
)
from flask_cors import CORS
from datetime import datetime, timedelta
from functools import wraps
import json, os, uuid, random, string, hashlib, time, threading

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "kacu-key-secret-2024-xnx")
CORS(app, resources={r"/api/*": {"origins": "*"}})

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")
STATIC = os.path.join(BASE, "static")
os.makedirs(DATA, exist_ok=True)
os.makedirs(STATIC, exist_ok=True)

# ── helpers de persistência ──────────────────────────────────────────
def load(name, default=None):
    path = os.path.join(DATA, name)
    if not os.path.exists(path):
        return default if default is not None else {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default if default is not None else {}

def save(name, obj):
    path = os.path.join(DATA, name)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def now():
    return datetime.utcnow()

def iso(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")

def parse_iso(s):
    try:
        return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ")
    except Exception:
        return now()

# ── dados iniciais ───────────────────────────────────────────────────
if not os.path.exists(os.path.join(DATA, "keys.json")):
    save("keys.json", {"free": [], "vip": []})
if not os.path.exists(os.path.join(DATA, "apps.json")):
    save("apps.json", [
        {
            "slot": 1, "published": True, "name": "KACU App 1",
            "version": "1.0", "desc": "App principal",
            "image": "", "link": "https://huggingface.co/chrislot2025/app/resolve/main/apk1.apk"
        },
        {
            "slot": 2, "published": True, "name": "KACU App 2",
            "version": "1.0", "desc": "App secundário",
            "image": "", "link": "https://huggingface.co/chrislot2025/app/resolve/main/apk.2apk"
        },
        {
            "slot": 3, "published": True, "name": "KACU App 3",
            "version": "1.0", "desc": "App 3",
            "image": "", "link": "https://huggingface.co/chrislot2025/app/resolve/main/apk.apk"
        },
        {"slot": 4, "published": False, "name": "", "version": "", "desc": "", "image": "", "link": ""},
        {"slot": 5, "published": False, "name": "", "version": "", "desc": "", "image": "", "link": ""},
    ])
if not os.path.exists(os.path.join(DATA, "vip_requests.json")):
    save("vip_requests.json", [])
if not os.path.exists(os.path.join(DATA, "notifications.json")):
    save("notifications.json", [])
if not os.path.exists(os.path.join(DATA, "id_shares.json")):
    save("id_shares.json", {})
if not os.path.exists(os.path.join(DATA, "xnx_apks.json")):
    save("xnx_apks.json", [
        {
            "id": "apk_001",
            "nome": "XNX Booster VIP 120FPS",
            "versao": "4.5.2",
            "link_download": "https://huggingface.co/chrislot2025/app/resolve/main/apk.apk",
            "imagem_url": "",
            "descricao": "Otimizador de sensibilidade e taxa de 120 FPS.",
            "categoria": "Games",
            "preco": 24.90,
            "estoque": 45,
            "tamanho": "18.4 MB",
            "pacote": "com.xnx.boostervip"
        }
    ])
if not os.path.exists(os.path.join(DATA, "xnx_vendas.json")):
    save("xnx_vendas.json", [])
if not os.path.exists(os.path.join(DATA, "config.json")):
    save("config.json", {
        "admin_user": "admin",
        "admin_pass": "kacu2024",
        "site_name": "KACU KEY",
        "youtube": "@KACU_PANEL",
        "youtube_url": "https://youtube.com/@KACU_PANEL",
        "key_duration_minutes": 60
    })

# ── auth painel ──────────────────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if not session.get("admin"):
            return redirect(url_for("painel_login"))
        return f(*args, **kwargs)
    return wrapped

# ── limpeza periódica de IDs expirados ───────────────────────────────
def cleanup_id_shares():
    shares = load("id_shares.json", {})
    changed = False
    now_ts = time.time()
    for code in list(shares.keys()):
        if shares[code].get("expires_at", 0) < now_ts:
            del shares[code]
            changed = True
    if changed:
        save("id_shares.json", shares)

# ══════════════════════════════════════════════════════════════════════
# PÁGINAS PÚBLICAS
# ══════════════════════════════════════════════════════════════════════

@app.route("/")
def index():
    return render_template("index.html", site_name="KACU KEY")

@app.route("/key")
def key_page():
    cfg = load("config.json")
    return render_template("key.html", site_name="KACU KEY", youtube=cfg.get("youtube", "@KACU_PANEL"), youtube_url=cfg.get("youtube_url", "https://youtube.com/@KACU_PANEL"))

@app.route("/vip")
def vip_page():
    return render_template("vip.html", site_name="KACU KEY")

@app.route("/apk")
def apk_page():
    apps = [a for a in load("apps.json", []) if a.get("published") and a.get("name")]
    return render_template("apk.html", site_name="KACU KEY", apps=apps)

# ══════════════════════════════════════════════════════════════════════
# API SENHAS
# ══════════════════════════════════════════════════════════════════════

@app.route("/api/gerar-free", methods=["POST"])
def gerar_free():
    data = request.get_json(silent=True) or {}
    # validação básica dos desafios (cliente já fez, aqui só gera)
    code = "FREE-" + "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
    cfg = load("config.json")
    mins = int(cfg.get("key_duration_minutes", 60))
    expires = now() + timedelta(minutes=mins)
    keys = load("keys.json", {"free": [], "vip": []})
    entry = {
        "code": code,
        "type": "FREE",
        "created": iso(now()),
        "expires": iso(expires),
        "active": True,
        "used": False
    }
    keys.setdefault("free", []).append(entry)
    save("keys.json", keys)
    return jsonify({
        "success": True,
        "code": code,
        "expires": iso(expires),
        "expiresInSeconds": mins * 60
    })

@app.route("/api/vip-request", methods=["POST"])
def vip_request():
    data = request.get_json(silent=True) or {}
    nome = (data.get("nome") or "").strip()
    email = (data.get("email") or "").strip()
    numero = (data.get("numero") or "").strip()
    pagamento = (data.get("pagamento") or "").strip()
    obs = (data.get("obs") or "").strip()
    if not nome or not email or not numero:
        return jsonify({"success": False, "message": "Preencha nome, e-mail e número."}), 400
    code = "VIP-" + "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
    cfg = load("config.json")
    mins = int(cfg.get("key_duration_minutes", 60)) * 24  # VIP dura mais
    expires = now() + timedelta(minutes=mins)
    keys = load("keys.json", {"free": [], "vip": []})
    entry = {
        "code": code,
        "type": "VIP",
        "created": iso(now()),
        "expires": iso(expires),
        "active": True,
        "used": False,
        "nome": nome,
        "email": email,
        "numero": numero
    }
    keys.setdefault("vip", []).append(entry)
    save("keys.json", keys)
    reqs = load("vip_requests.json", [])
    reqs.append({
        "id": str(uuid.uuid4())[:8],
        "nome": nome,
        "email": email,
        "numero": numero,
        "pagamento": pagamento,
        "obs": obs,
        "code": code,
        "created": iso(now())
    })
    save("vip_requests.json", reqs)
    return jsonify({
        "success": True,
        "code": code,
        "expires": iso(expires),
        "expiresInSeconds": mins * 60
    })

@app.route("/api/keys/status")
def keys_status():
    keys = load("keys.json", {"free": [], "vip": []})
    now_dt = now()
    def count_active(lst):
        n = 0
        for k in lst:
            if not k.get("active"):
                continue
            exp = parse_iso(k.get("expires", "2000-01-01T00:00:00Z"))
            if exp > now_dt:
                n += 1
        return n
    free_n = count_active(keys.get("free", []))
    vip_n = count_active(keys.get("vip", []))
    return jsonify({"free": free_n, "vip": vip_n, "total": free_n + vip_n})

# ══════════════════════════════════════════════════════════════════════
# API NOTIFICAÇÃO
# ══════════════════════════════════════════════════════════════════════

@app.route("/api/notification", methods=["GET", "POST"])
@app.route("/api/notifications", methods=["GET", "POST"])
@app.route("/api/notify", methods=["GET", "POST"])
def api_notification():
    notifs = load("notifications.json", [])
    if request.method == "POST":
        data = request.get_json(silent=True) or {}
        title = data.get("title") or data.get("titulo") or "Aviso"
        message = data.get("message") or data.get("text") or data.get("body") or data.get("mensagem") or ""
        entry = {
            "id": len(notifs) + 1,
            "title": title,
            "message": message,
            "text": message,
            "body": message,
            "created": iso(now())
        }
        notifs.insert(0, entry)
        notifs = notifs[:50]
        save("notifications.json", notifs)
        return jsonify({"success": True, "notification": entry})
    # GET
    if not notifs:
        return jsonify({
            "id": 0,
            "title": "",
            "message": "",
            "text": "",
            "body": "",
            "notifications": []
        })
    latest = notifs[0]
    return jsonify({
        "id": latest.get("id", 1),
        "title": latest.get("title", ""),
        "message": latest.get("message", ""),
        "text": latest.get("text", latest.get("message", "")),
        "body": latest.get("body", latest.get("message", "")),
        "notifications": notifs
    })

# ══════════════════════════════════════════════════════════════════════
# API ID – compartilhar IDs por QR / código
# ══════════════════════════════════════════════════════════════════════

@app.route("/api/id")
@app.route("/api/ids")
def api_id_info():
    return jsonify({
        "name": "ID",
        "status": "online",
        "endpoints": {
            "share_post": "/api/id/share",
            "share_get": "/api/id/share/<shareCode>",
            "aliases": ["/api/ids/share", "/api/ids/share/<shareCode>"]
        },
        "expiresInMinutes": 30
    })

@app.route("/api/id/share", methods=["POST", "OPTIONS"])
@app.route("/api/ids/share", methods=["POST", "OPTIONS"])
def id_share_post():
    if request.method == "OPTIONS":
        return "", 204
    cleanup_id_shares()
    data = request.get_json(silent=True) or {}
    share_code = (data.get("shareCode") or data.get("code") or "").strip().upper()
    if not share_code:
        share_code = "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
    items = data.get("items") or data.get("ids") or []
    sender = data.get("senderDevice") or data.get("device") or "Desconhecido"
    total = data.get("totalItems") or len(items)
    expires_min = 30
    entry = {
        "shareCode": share_code,
        "senderDevice": sender,
        "totalItems": total,
        "items": items,
        "created_at": time.time(),
        "expires_at": time.time() + expires_min * 60
    }
    shares = load("id_shares.json", {})
    shares[share_code] = entry
    save("id_shares.json", shares)
    return jsonify({
        "success": True,
        "shareCode": share_code,
        "message": "IDs publicados com sucesso!",
        "expiresInMinutes": expires_min
    }), 201

@app.route("/api/id/share/<share_code>", methods=["GET", "OPTIONS"])
@app.route("/api/ids/share/<share_code>", methods=["GET", "OPTIONS"])
def id_share_get(share_code):
    if request.method == "OPTIONS":
        return "", 204
    cleanup_id_shares()
    code = share_code.strip().upper()
    shares = load("id_shares.json", {})
    entry = shares.get(code)
    if not entry or entry.get("expires_at", 0) < time.time():
        return jsonify({
            "success": False,
            "message": "Código expirado ou não encontrado."
        }), 404
    return jsonify({
        "success": True,
        "shareCode": code,
        "senderDevice": entry.get("senderDevice", ""),
        "totalItems": entry.get("totalItems", 0),
        "items": entry.get("items", [])
    })

# ══════════════════════════════════════════════════════════════════════
# API XNX LOJA – catálogo de APKs + vendas automáticas
# ══════════════════════════════════════════════════════════════════════

@app.route("/api/apks", methods=["GET", "OPTIONS"])
def api_apks():
    """Endpoint que o XNX LOJA puxa o catálogo."""
    if request.method == "OPTIONS":
        return "", 204
    apks = load("xnx_apks.json", [])
    # só retorna os que têm estoque > 0 (opcional – o app pode filtrar)
    return jsonify({
        "status": "success",
        "loja": "XNX LOJA",
        "apks": apks
    })

@app.route("/api/vendas", methods=["POST", "OPTIONS"])
def api_vendas():
    """Registra venda automática e gera chave de licença."""
    if request.method == "OPTIONS":
        return "", 204
    data = request.get_json(silent=True) or {}
    apk_id = data.get("apkId") or data.get("apk_id") or data.get("id") or ""
    comprador = data.get("comprador") or data.get("buyer") or "Cliente"
    valor = data.get("valor") or data.get("price") or 0
    chave = data.get("chaveLicenca") or data.get("license") or ""

    apks = load("xnx_apks.json", [])
    found = None
    for a in apks:
        if a.get("id") == apk_id:
            found = a
            break

    if found:
        # subtrai estoque
        estoque = int(found.get("estoque", 0))
        if estoque > 0:
            found["estoque"] = estoque - 1
            save("xnx_apks.json", apks)
        if not chave:
            # gera chave VIP no formato do tutorial
            chave = "XNX-VIP-" + "".join(random.choices(string.digits, k=3)) + "-" + \
                    "".join(random.choices(string.ascii_uppercase + string.digits, k=6))

    venda = {
        "id": str(uuid.uuid4())[:8],
        "apkId": apk_id,
        "apkNome": found.get("nome") if found else "",
        "comprador": comprador,
        "valor": valor,
        "chaveLicenca": chave,
        "created": iso(now())
    }
    vendas = load("xnx_vendas.json", [])
    vendas.insert(0, venda)
    vendas = vendas[:200]
    save("xnx_vendas.json", vendas)

    return jsonify({
        "success": True,
        "message": "Venda registrada!",
        "chaveLicenca": chave,
        "estoqueRestante": found.get("estoque") if found else None
    })

# ══════════════════════════════════════════════════════════════════════
# DOWNLOAD PROXY (não mostra link direto)
# ══════════════════════════════════════════════════════════════════════

@app.route("/download/<int:slot>")
def download_proxy(slot):
    apps = load("apps.json", [])
    app_item = None
    for a in apps:
        if a.get("slot") == slot and a.get("published"):
            app_item = a
            break
    if not app_item or not app_item.get("link"):
        return "Arquivo não encontrado", 404
    # redireciona internamente – o usuário não vê o link no HTML
    return redirect(app_item["link"])

@app.route("/xnx-download/<apk_id>")
def xnx_download(apk_id):
    apks = load("xnx_apks.json", [])
    for a in apks:
        if a.get("id") == apk_id:
            link = a.get("link_download")
            if link:
                return redirect(link)
    return "Arquivo não encontrado", 404

# ══════════════════════════════════════════════════════════════════════
# PAINEL ADMIN
# ══════════════════════════════════════════════════════════════════════

@app.route("/painel-x7k9", methods=["GET", "POST"])
def painel_login():
    if request.method == "POST":
        user = request.form.get("user", "")
        pwd = request.form.get("pass", "")
        cfg = load("config.json")
        if user == cfg.get("admin_user") and pwd == cfg.get("admin_pass"):
            session["admin"] = True
            return redirect(url_for("painel"))
        return render_template("login.html", error="Usuário ou senha incorretos")
    if session.get("admin"):
        return redirect(url_for("painel"))
    return render_template("login.html")

@app.route("/painel")
@login_required
def painel():
    keys = load("keys.json", {"free": [], "vip": []})
    now_dt = now()
    def enrich(lst):
        out = []
        for k in lst:
            exp = parse_iso(k.get("expires", "2000-01-01T00:00:00Z"))
            remaining = max(0, int((exp - now_dt).total_seconds()))
            k2 = dict(k)
            k2["remaining"] = remaining
            k2["expired"] = remaining <= 0
            out.append(k2)
        return list(reversed(out[-50:]))  # últimas 50
    free_list = enrich(keys.get("free", []))
    vip_list = enrich(keys.get("vip", []))
    free_active = sum(1 for k in free_list if not k["expired"] and k.get("active"))
    vip_active = sum(1 for k in vip_list if not k["expired"] and k.get("active"))
    apps = load("apps.json", [])
    vip_reqs = list(reversed(load("vip_requests.json", [])[-30:]))
    notifs = load("notifications.json", [])
    shares = load("id_shares.json", {})
    cleanup_id_shares()
    shares = load("id_shares.json", {})
    id_list = []
    for code, e in shares.items():
        left = max(0, int(e.get("expires_at", 0) - time.time()))
        id_list.append({
            "code": code,
            "device": e.get("senderDevice", ""),
            "total": e.get("totalItems", 0),
            "items": e.get("items", []),
            "remaining": left
        })
    xnx_apks = load("xnx_apks.json", [])
    xnx_vendas = load("xnx_vendas.json", [])
    return render_template(
        "painel.html",
        free_list=free_list, vip_list=vip_list,
        free_active=free_active, vip_active=vip_active,
        apps=apps, vip_reqs=vip_reqs, notifs=notifs,
        id_list=id_list, xnx_apks=xnx_apks, xnx_vendas=xnx_vendas
    )

@app.route("/painel/logout")
def painel_logout():
    session.clear()
    return redirect(url_for("painel_login"))

@app.route("/painel/save-apps", methods=["POST"])
@login_required
def painel_save_apps():
    apps = []
    for i in range(1, 6):
        apps.append({
            "slot": i,
            "published": request.form.get(f"pub_{i}") == "on",
            "name": request.form.get(f"name_{i}", "").strip(),
            "version": request.form.get(f"ver_{i}", "").strip(),
            "desc": request.form.get(f"desc_{i}", "").strip(),
            "image": request.form.get(f"img_{i}", "").strip(),
            "link": request.form.get(f"link_{i}", "").strip(),
        })
    save("apps.json", apps)
    return redirect(url_for("painel") + "#app")

@app.route("/painel/notify", methods=["POST"])
@login_required
def painel_notify():
    title = request.form.get("title", "Aviso")
    message = request.form.get("message", "")
    notifs = load("notifications.json", [])
    notifs.insert(0, {
        "id": len(notifs) + 1,
        "title": title,
        "message": message,
        "text": message,
        "body": message,
        "created": iso(now())
    })
    save("notifications.json", notifs[:50])
    return redirect(url_for("painel") + "#notif")

@app.route("/painel/xnx-save", methods=["POST"])
@login_required
def painel_xnx_save():
    apks = load("xnx_apks.json", [])
    action = request.form.get("action", "update")
    if action == "add":
        new_id = "apk_" + "".join(random.choices(string.digits, k=3))
        apks.append({
            "id": new_id,
            "nome": request.form.get("nome", "").strip(),
            "versao": request.form.get("versao", "1.0").strip(),
            "link_download": request.form.get("link_download", "").strip(),
            "imagem_url": request.form.get("imagem_url", "").strip(),
            "descricao": request.form.get("descricao", "").strip(),
            "categoria": request.form.get("categoria", "Games").strip(),
            "preco": float(request.form.get("preco") or 0),
            "estoque": int(request.form.get("estoque") or 0),
            "tamanho": request.form.get("tamanho", "").strip(),
            "pacote": request.form.get("pacote", "").strip(),
        })
    elif action == "update":
        apk_id = request.form.get("id", "")
        for a in apks:
            if a.get("id") == apk_id:
                a["nome"] = request.form.get("nome", a["nome"]).strip()
                a["versao"] = request.form.get("versao", a["versao"]).strip()
                a["link_download"] = request.form.get("link_download", a["link_download"]).strip()
                a["imagem_url"] = request.form.get("imagem_url", a.get("imagem_url", "")).strip()
                a["descricao"] = request.form.get("descricao", a.get("descricao", "")).strip()
                a["categoria"] = request.form.get("categoria", a.get("categoria", "")).strip()
                try:
                    a["preco"] = float(request.form.get("preco") or a.get("preco", 0))
                except Exception:
                    pass
                try:
                    a["estoque"] = int(request.form.get("estoque") or a.get("estoque", 0))
                except Exception:
                    pass
                a["tamanho"] = request.form.get("tamanho", a.get("tamanho", "")).strip()
                a["pacote"] = request.form.get("pacote", a.get("pacote", "")).strip()
                break
    elif action == "delete":
        apk_id = request.form.get("id", "")
        apks = [a for a in apks if a.get("id") != apk_id]
    save("xnx_apks.json", apks)
    return redirect(url_for("painel") + "#xnx")

@app.route("/painel/toggle-key", methods=["POST"])
@login_required
def toggle_key():
    data = request.get_json(silent=True) or {}
    code = data.get("code", "")
    keys = load("keys.json", {"free": [], "vip": []})
    for lst in (keys.get("free", []), keys.get("vip", [])):
        for k in lst:
            if k.get("code") == code:
                k["active"] = not k.get("active", True)
                save("keys.json", keys)
                return jsonify({"success": True, "active": k["active"]})
    return jsonify({"success": False}), 404

# ── static ───────────────────────────────────────────────────────────
@app.route("/static/<path:filename>")
def static_files(filename):
    return send_from_directory(STATIC, filename)

# ── health ───────────────────────────────────────────────────────────
@app.route("/health")
def health():
    return jsonify({"ok": True, "service": "KACU KEY"})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 10000))
    app.run(host="0.0.0.0", port=port, debug=False)
