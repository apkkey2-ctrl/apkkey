import os
import json
import sqlite3
import secrets
import string
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, render_template, redirect, session, g

app = Flask(__name__)


@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    return response


@app.route("/api/<path:_any>", methods=["OPTIONS"])
def cors_preflight(_any):
    return "", 204


ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "Troque#Esta1Senha")
app.secret_key = os.environ.get("SECRET_KEY", secrets.token_hex(16))

KEY_LENGTH_FREE = 10
KEY_LENGTH_VIP = 24
KEY_TTL_HOURS = 1
DB_PATH = os.path.join(os.path.dirname(__file__), "keys.db")

SOCIAL_LINKS = {
    "instagram": "https://www.instagram.com/rp_cris47",
    "whatsapp": "https://whatsapp.com/channel/0029VbCpyfeEgGfHP3DNvl1e",
    "telegram": "https://t.me/ggfpanel",
}

SITE_NAME = "KACU KEY"


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS keys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            tier TEXT NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS vip_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            code TEXT,
            created_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


def get_setting(key, default=""):
    db = get_db()
    row = db.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(key, value):
    db = get_db()
    db.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )
    db.commit()


def get_apps():
    raw = get_setting("apps_json", "[]")
    try:
        data = json.loads(raw)
        if isinstance(data, list):
            return data
    except json.JSONDecodeError:
        pass
    return []


def generate_code(tier):
    alphabet = string.ascii_uppercase + string.digits
    length = KEY_LENGTH_VIP if tier == "vip" else KEY_LENGTH_FREE
    body = "".join(secrets.choice(alphabet) for _ in range(length))
    prefix = "VIP-" if tier == "vip" else "FREE-"
    return prefix + body


def cleanup_expired_keys():
    db = get_db()
    db.execute("DELETE FROM keys WHERE expires_at < ?", (datetime.utcnow().isoformat(),))
    db.commit()


def create_key(tier):
    db = get_db()
    code = generate_code(tier)
    now = datetime.utcnow()
    expires = now + timedelta(hours=KEY_TTL_HOURS)
    db.execute(
        "INSERT INTO keys (code, tier, created_at, expires_at, active) VALUES (?, ?, ?, ?, 1)",
        (code, tier, now.isoformat(), expires.isoformat()),
    )
    db.commit()
    return code, expires


@app.route("/")
def home():
    return render_template(
        "index.html",
        links=SOCIAL_LINKS,
        support_email=get_setting("support_email"),
        apps=get_apps(),
        site_name=SITE_NAME,
    )


@app.route("/termos")
def termos():
    return render_template(
        "termos.html",
        support_email=get_setting("support_email"),
        site_name=SITE_NAME,
    )


@app.route("/vip")
def vip_page():
    return render_template(
        "vip.html",
        telegram=SOCIAL_LINKS["telegram"],
        support_email=get_setting("support_email"),
        site_name=SITE_NAME,
    )


@app.route("/apk")
@app.route("/APK")
def apk_page():
    return render_template(
        "apk.html",
        version=get_setting("apk_version"),
        description=get_setting("apk_description"),
        link=get_setting("apk_link"),
        apps=get_apps(),
        site_name=SITE_NAME,
    )


@app.route("/api/generate-free", methods=["POST"])
def api_generate_free():
    cleanup_expired_keys()
    code, expires = create_key("free")
    return jsonify({"code": code, "tier": "free", "expires_at": expires.isoformat() + "Z"})


@app.route("/api/generate-vip", methods=["POST"])
def api_generate_vip():
    cleanup_expired_keys()
    data = request.get_json(silent=True) or {}
    full_name = (data.get("full_name") or request.form.get("full_name") or "").strip()
    email = (data.get("email") or request.form.get("email") or "").strip()
    phone = (data.get("phone") or request.form.get("phone") or "").strip()

    if not full_name or not email or not phone:
        return jsonify({"error": "Preencha nome completo, e-mail e número."}), 400
    if "@" not in email or "." not in email:
        return jsonify({"error": "E-mail inválido."}), 400

    code, expires = create_key("vip")
    db = get_db()
    db.execute(
        "INSERT INTO vip_requests (full_name, email, phone, code, created_at) VALUES (?, ?, ?, ?, ?)",
        (full_name, email, phone, code, datetime.utcnow().isoformat()),
    )
    db.commit()
    return jsonify({
        "code": code,
        "tier": "vip",
        "expires_at": expires.isoformat() + "Z",
    })


@app.route("/api/notification")
def api_notification():
    return jsonify({
        "id": get_setting("notification_id", "0"),
        "message": get_setting("notification_message", ""),
        "sent_at": get_setting("notification_sent_at", ""),
    })


@app.route("/api/validate", methods=["POST"])
def api_validate():
    data = request.get_json(silent=True) or {}
    code = (data.get("code") or "").strip().upper()

    if not code:
        return jsonify({"valid": False, "reason": "Nenhuma senha enviada."}), 400

    db = get_db()
    row = db.execute("SELECT * FROM keys WHERE code = ?", (code,)).fetchone()

    if row is None:
        return jsonify({"valid": False, "reason": "Senha não encontrada."}), 404
    if not row["active"]:
        return jsonify({"valid": False, "reason": "Senha desativada."}), 403

    expires_at = datetime.fromisoformat(row["expires_at"])
    if datetime.utcnow() > expires_at:
        db.execute("DELETE FROM keys WHERE id = ?", (row["id"],))
        db.commit()
        return jsonify({"valid": False, "reason": "Senha expirada."}), 403

    return jsonify({
        "valid": True,
        "tier": row["tier"],
        "expires_at": row["expires_at"] + "Z",
    })


@app.route("/painel-x7k9", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        senha = request.form.get("senha", "")
        if senha == ADMIN_PASSWORD:
            session["admin"] = True
            return redirect("/painel-x7k9/dashboard")
        return render_template("admin_login.html", erro="Senha incorreta.", site_name=SITE_NAME)
    return render_template("admin_login.html", erro=None, site_name=SITE_NAME)


@app.route("/painel-x7k9/dashboard")
def admin_dashboard():
    if not session.get("admin"):
        return redirect("/painel-x7k9")

    cleanup_expired_keys()
    db = get_db()
    rows = db.execute("SELECT * FROM keys ORDER BY id DESC").fetchall()
    now = datetime.utcnow()
    keys = []
    for r in rows:
        expires_at = datetime.fromisoformat(r["expires_at"])
        keys.append({
            "id": r["id"],
            "code": r["code"],
            "tier": r["tier"],
            "created_at": r["created_at"],
            "expires_at": r["expires_at"],
            "active": bool(r["active"]),
            "expired": now > expires_at,
        })

    vip_rows = db.execute("SELECT * FROM vip_requests ORDER BY id DESC LIMIT 50").fetchall()
    vip_requests = [dict(v) for v in vip_rows]

    return render_template(
        "admin_dashboard.html",
        keys=keys,
        support_email=get_setting("support_email"),
        apk_version=get_setting("apk_version"),
        apk_description=get_setting("apk_description"),
        apk_link=get_setting("apk_link"),
        apps=get_apps(),
        notification_message=get_setting("notification_message"),
        notification_sent_at=get_setting("notification_sent_at"),
        vip_requests=vip_requests,
        site_name=SITE_NAME,
    )


@app.route("/painel-x7k9/salvar-suporte", methods=["POST"])
def admin_salvar_suporte():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    email = request.form.get("support_email", "").strip()
    set_setting("support_email", email)
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/publicar-apk", methods=["POST"])
def admin_publicar_apk():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    set_setting("apk_link", request.form.get("apk_link", "").strip())
    set_setting("apk_version", request.form.get("apk_version", "").strip())
    set_setting("apk_description", request.form.get("apk_description", "").strip())
    return redirect("/painel-x7k9/dashboard#app")


@app.route("/painel-x7k9/despublicar-apk", methods=["POST"])
def admin_despublicar_apk():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    set_setting("apk_link", "")
    set_setting("apk_version", "")
    set_setting("apk_description", "")
    return redirect("/painel-x7k9/dashboard#app")


@app.route("/painel-x7k9/salvar-apps", methods=["POST"])
def admin_salvar_apps():
    if not session.get("admin"):
        return redirect("/painel-x7k9")

    names = request.form.getlist("app_name")
    images = request.form.getlist("app_image")
    links = request.form.getlist("app_link")
    apps = []
    for name, image, link in zip(names, images, links):
        name = (name or "").strip()
        image = (image or "").strip()
        link = (link or "").strip()
        if name or image or link:
            apps.append({"name": name, "image": image, "link": link})
    set_setting("apps_json", json.dumps(apps, ensure_ascii=False))
    return redirect("/painel-x7k9/dashboard#app")


@app.route("/painel-x7k9/gerar-vip", methods=["POST"])
def admin_gerar_vip():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    create_key("vip")
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/desativar/<int:key_id>", methods=["POST"])
def admin_desativar(key_id):
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    db = get_db()
    db.execute("UPDATE keys SET active = 0 WHERE id = ?", (key_id,))
    db.commit()
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/apagar/<int:key_id>", methods=["POST"])
def admin_apagar(key_id):
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    db = get_db()
    db.execute("DELETE FROM keys WHERE id = ?", (key_id,))
    db.commit()
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/limpar-expiradas", methods=["POST"])
def admin_limpar_expiradas():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    cleanup_expired_keys()
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/enviar-notificacao", methods=["POST"])
def admin_enviar_notificacao():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    mensagem = request.form.get("mensagem", "").strip()
    if mensagem:
        novo_id = int(get_setting("notification_id", "0")) + 1
        set_setting("notification_id", str(novo_id))
        set_setting("notification_message", mensagem)
        set_setting("notification_sent_at", datetime.utcnow().isoformat() + "Z")
    return redirect("/painel-x7k9/dashboard#notificacao")


@app.route("/painel-x7k9/sair")
def admin_logout():
    session.pop("admin", None)
    return redirect("/painel-x7k9")


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 7860)))
else:
    init_db()
