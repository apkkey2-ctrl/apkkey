import os
import json
import sqlite3
import secrets
import string
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, render_template, redirect, session, g

app = Flask(__name__)


@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    return response


@app.route("/api/<path:_any>", methods=["OPTIONS"])
def cors_preflight(_any):
    return "", 204


ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "Troque#Esta1Senha")
app.secret_key = os.environ.get("SECRET_KEY", secrets.token_hex(16))

KEY_LENGTH_FREE = 10
KEY_LENGTH_VIP = 24
KEY_TTL_HOURS = 1
DB_PATH = os.path.join(os.path.dirname(__file__), "keys.db")

SOCIAL_LINKS = {
    "instagram": "https://www.instagram.com/rp_cris47",
    "whatsapp": "https://whatsapp.com/channel/0029VbCpyfeEgGfHP3DNvl1e",
    "telegram": "https://t.me/ggfpanel",
    "youtube": "https://www.youtube.com/@KACU_PANEL",
}

SITE_NAME = "KACU KEY"


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS keys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            tier TEXT NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS vip_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            code TEXT,
            created_at TEXT NOT NULL
        )
    """)
    cols = {row[1] for row in conn.execute("PRAGMA table_info(vip_requests)").fetchall()}
    if "payment_method" not in cols:
        conn.execute("ALTER TABLE vip_requests ADD COLUMN payment_method TEXT")
    if "notes" not in cols:
        conn.execute("ALTER TABLE vip_requests ADD COLUMN notes TEXT")
    # XNX LOJA — catálogo de APKs e vendas automáticas
    conn.execute("""
        CREATE TABLE IF NOT EXISTS xnx_apks (
            id TEXT PRIMARY KEY,
            nome TEXT NOT NULL,
            versao TEXT,
            link_download TEXT,
            imagem_url TEXT,
            descricao TEXT,
            categoria TEXT,
            preco REAL DEFAULT 0,
            estoque INTEGER DEFAULT 0,
            tamanho TEXT,
            pacote TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS xnx_vendas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            apk_id TEXT,
            apk_nome TEXT,
            comprador TEXT,
            valor REAL,
            chave_licenca TEXT,
            created_at TEXT NOT NULL
        )
    """)
    count = conn.execute("SELECT COUNT(*) FROM xnx_apks").fetchone()[0]
    if count == 0:
        conn.execute(
            "INSERT INTO xnx_apks (id, nome, versao, link_download, imagem_url, descricao, categoria, preco, estoque, tamanho, pacote) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                "apk_001",
                "XNX Booster VIP 120FPS",
                "4.5.2",
                "https://huggingface.co/chrislot2025/app/resolve/main/apk.apk",
                "",
                "Otimizador de sensibilidade e taxa de 120 FPS.",
                "Games",
                24.90,
                45,
                "18.4 MB",
                "com.xnx.boostervip",
            ),
        )
    conn.commit()
    conn.close()


def get_setting(key, default=""):
    db = get_db()
    row = db.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(key, value):
    db = get_db()
    db.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )
    db.commit()


def get_apps():
    raw = get_setting("apps_json", "[]")
    try:
        data = json.loads(raw)
        if isinstance(data, list):
            return data
    except json.JSONDecodeError:
        pass
    return []


def generate_code(tier):
    alphabet = string.ascii_uppercase + string.digits
    length = KEY_LENGTH_VIP if tier == "vip" else KEY_LENGTH_FREE
    body = "".join(secrets.choice(alphabet) for _ in range(length))
    prefix = "VIP-" if tier == "vip" else "FREE-"
    return prefix + body


def utcnow():
    return datetime.utcnow().replace(microsecond=0)


def parse_dt(value):
    if not value:
        return None
    text = str(value).strip().replace("Z", "")
    if "." in text:
        text = text.split(".", 1)[0]
    try:
        return datetime.fromisoformat(text)
    except ValueError:
        return None


def stamp(dt=None):
    return (dt or utcnow()).strftime("%Y-%m-%dT%H:%M:%S")


def cleanup_expired_keys():
    """Marca como inativa. Não apaga sozinha, para o painel não 'sumir' com senha ativa."""
    db = get_db()
    now = stamp()
    db.execute("UPDATE keys SET active = 0 WHERE expires_at < ? AND active = 1", (now,))
    db.commit()


def create_key(tier):
    db = get_db()
    code = generate_code(tier)
    now = utcnow()
    expires = now + timedelta(hours=KEY_TTL_HOURS)
    db.execute(
        "INSERT INTO keys (code, tier, created_at, expires_at, active) VALUES (?, ?, ?, ?, 1)",
        (code, tier, stamp(now), stamp(expires)),
    )
    db.commit()
    return code, expires


@app.route("/")
def home():
    return render_template(
        "index.html",
        links=SOCIAL_LINKS,
        support_email=get_setting("support_email"),
        apps=get_apps(),
        site_name=SITE_NAME,
    )


@app.route("/termos")
def termos():
    return render_template(
        "termos.html",
        support_email=get_setting("support_email"),
        site_name=SITE_NAME,
    )


@app.route("/vip")
def vip_page():
    return render_template(
        "vip.html",
        telegram=SOCIAL_LINKS["telegram"],
        support_email=get_setting("support_email"),
        site_name=SITE_NAME,
    )


@app.route("/apk")
@app.route("/APK")
def apk_page():
    return render_template(
        "apk.html",
        version=get_setting("apk_version"),
        description=get_setting("apk_description"),
        link=get_setting("apk_link"),
        apps=get_apps(),
        site_name=SITE_NAME,
    )


@app.route("/api/generate-free", methods=["POST"])
def api_generate_free():
    cleanup_expired_keys()
    code, expires = create_key("free")
    return jsonify({"code": code, "tier": "free", "expires_at": expires.isoformat() + "Z"})


@app.route("/api/generate-vip", methods=["POST"])
def api_generate_vip():
    cleanup_expired_keys()
    data = request.get_json(silent=True) or {}
    full_name = (data.get("full_name") or request.form.get("full_name") or "").strip()
    email = (data.get("email") or request.form.get("email") or "").strip()
    phone = (data.get("phone") or request.form.get("phone") or "").strip()
    payment_method = (data.get("payment_method") or request.form.get("payment_method") or "").strip()
    notes = (data.get("notes") or request.form.get("notes") or "").strip()

    if not full_name or not email or not phone:
        return jsonify({"error": "Preencha nome completo, e-mail e número."}), 400
    if "@" not in email or "." not in email:
        return jsonify({"error": "E-mail inválido."}), 400

    code, expires = create_key("vip")
    db = get_db()
    db.execute(
        "INSERT INTO vip_requests (full_name, email, phone, code, created_at, payment_method, notes) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (full_name, email, phone, code, datetime.utcnow().isoformat(), payment_method, notes),
    )
    db.commit()
    return jsonify({
        "code": code,
        "tier": "vip",
        "expires_at": expires.isoformat() + "Z",
    })


def build_notification_payload():
    raw_id = get_setting("notification_id", "0")
    try:
        nid = int(raw_id)
    except ValueError:
        nid = 0
    message = get_setting("notification_message", "")
    sent_at = get_setting("notification_sent_at", "")
    title = get_setting("notification_title", "KACU KEY")
    item = {
        "id": nid,
        "title": title,
        "message": message,
        "text": message,
        "body": message,
        "content": message,
        "sent_at": sent_at,
        "timestamp": sent_at,
        "created_at": sent_at,
    }
    return {
        "ok": True,
        "success": True,
        "active": bool(message),
        "id": nid,
        "notification_id": nid,
        "title": title,
        "message": message,
        "text": message,
        "body": message,
        "content": message,
        "sent_at": sent_at,
        "timestamp": sent_at,
        "created_at": sent_at,
        "notification": item,
        "data": item,
        "notifications": [item] if message else [],
    }


@app.route("/api/notification", methods=["GET", "POST"])
@app.route("/api/notifications", methods=["GET", "POST"])
@app.route("/api/notify", methods=["GET", "POST"])
def api_notification():
    resp = jsonify(build_notification_payload())
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    return resp


@app.route("/api/validate", methods=["POST"])
def api_validate():
    data = request.get_json(silent=True) or {}
    code = (data.get("code") or "").strip().upper()

    if not code:
        return jsonify({"valid": False, "reason": "Nenhuma senha enviada."}), 400

    db = get_db()
    row = db.execute("SELECT * FROM keys WHERE code = ?", (code,)).fetchone()

    if row is None:
        return jsonify({"valid": False, "reason": "Senha não encontrada."}), 404
    if not row["active"]:
        return jsonify({"valid": False, "reason": "Senha desativada."}), 403

    expires_at = parse_dt(row["expires_at"])
    if expires_at is None or utcnow() > expires_at:
        db.execute("DELETE FROM keys WHERE id = ?", (row["id"],))
        db.commit()
        return jsonify({"valid": False, "reason": "Senha expirada."}), 403

    return jsonify({
        "valid": True,
        "tier": row["tier"],
        "expires_at": row["expires_at"] + "Z",
    })


@app.route("/painel-x7k9", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        senha = request.form.get("senha", "")
        if senha == ADMIN_PASSWORD:
            session["admin"] = True
            return redirect("/painel-x7k9/dashboard")
        return render_template("admin_login.html", erro="Senha incorreta.", site_name=SITE_NAME)
    return render_template("admin_login.html", erro=None, site_name=SITE_NAME)


@app.route("/painel-x7k9/dashboard")
def admin_dashboard():
    if not session.get("admin"):
        return redirect("/painel-x7k9")

    cleanup_expired_keys()
    db = get_db()
    now = utcnow()
    now_s = stamp(now)
    rows = db.execute("SELECT * FROM keys ORDER BY id DESC").fetchall()
    keys = []
    for r in rows:
        expires_at = parse_dt(r["expires_at"]) or now
        still_valid = bool(r["active"]) and expires_at > now
        left = max(0, int((expires_at - now).total_seconds())) if still_valid else 0
        keys.append({
            "id": r["id"],
            "code": r["code"],
            "tier": r["tier"],
            "created_at": r["created_at"],
            "expires_at": r["expires_at"],
            "active": still_valid,
            "expired": expires_at <= now,
            "left": left,
        })

    vip_rows = db.execute("SELECT * FROM vip_requests ORDER BY id DESC LIMIT 50").fetchall()
    vip_requests = [dict(v) for v in vip_rows]
    # Contagem direta no banco, igual à regra de "ainda vale"
    active_count = db.execute(
        "SELECT COUNT(*) AS n FROM keys WHERE active = 1 AND expires_at > ?",
        (now_s,),
    ).fetchone()["n"]
    active_free = db.execute(
        "SELECT COUNT(*) AS n FROM keys WHERE active = 1 AND tier = 'free' AND expires_at > ?",
        (now_s,),
    ).fetchone()["n"]
    active_vip = db.execute(
        "SELECT COUNT(*) AS n FROM keys WHERE active = 1 AND tier = 'vip' AND expires_at > ?",
        (now_s,),
    ).fetchone()["n"]

    xnx_rows = db.execute("SELECT * FROM xnx_apks ORDER BY nome").fetchall()
    xnx_apks = [dict(r) for r in xnx_rows]
    venda_rows = db.execute("SELECT * FROM xnx_vendas ORDER BY id DESC LIMIT 50").fetchall()
    xnx_vendas = [dict(v) for v in venda_rows]

    return render_template(
        "admin_dashboard.html",
        keys=keys,
        active_count=active_count,
        active_free=active_free,
        active_vip=active_vip,
        support_email=get_setting("support_email"),
        apk_version=get_setting("apk_version"),
        apk_description=get_setting("apk_description"),
        apk_link=get_setting("apk_link"),
        apps=get_apps(),
        notification_message=get_setting("notification_message"),
        notification_title=get_setting("notification_title", "KACU KEY"),
        notification_sent_at=get_setting("notification_sent_at"),
        vip_requests=vip_requests,
        xnx_apks=xnx_apks,
        xnx_vendas=xnx_vendas,
        site_name=SITE_NAME,
    )


@app.route("/painel-x7k9/salvar-suporte", methods=["POST"])
def admin_salvar_suporte():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    email = request.form.get("support_email", "").strip()
    set_setting("support_email", email)
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/publicar-apk", methods=["POST"])
def admin_publicar_apk():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    set_setting("apk_link", request.form.get("apk_link", "").strip())
    set_setting("apk_version", request.form.get("apk_version", "").strip())
    set_setting("apk_description", request.form.get("apk_description", "").strip())
    return redirect("/painel-x7k9/dashboard#app")


@app.route("/painel-x7k9/despublicar-apk", methods=["POST"])
def admin_despublicar_apk():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    set_setting("apk_link", "")
    set_setting("apk_version", "")
    set_setting("apk_description", "")
    return redirect("/painel-x7k9/dashboard#app")


@app.route("/painel-x7k9/salvar-apps", methods=["POST"])
def admin_salvar_apps():
    if not session.get("admin"):
        return redirect("/painel-x7k9")

    names = request.form.getlist("app_name")
    images = request.form.getlist("app_image")
    links = request.form.getlist("app_link")
    apps = []
    for name, image, link in zip(names, images, links):
        name = (name or "").strip()
        image = (image or "").strip()
        link = (link or "").strip()
        if name or image or link:
            apps.append({"name": name, "image": image, "link": link})
    set_setting("apps_json", json.dumps(apps, ensure_ascii=False))
    return redirect("/painel-x7k9/dashboard#app")


@app.route("/painel-x7k9/gerar-vip", methods=["POST"])
def admin_gerar_vip():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    create_key("vip")
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/desativar/<int:key_id>", methods=["POST"])
def admin_desativar(key_id):
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    db = get_db()
    db.execute("UPDATE keys SET active = 0 WHERE id = ?", (key_id,))
    db.commit()
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/apagar/<int:key_id>", methods=["POST"])
def admin_apagar(key_id):
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    db = get_db()
    db.execute("DELETE FROM keys WHERE id = ?", (key_id,))
    db.commit()
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/limpar-expiradas", methods=["POST"])
def admin_limpar_expiradas():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    cleanup_expired_keys()
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/enviar-notificacao", methods=["POST"])
def admin_enviar_notificacao():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    mensagem = request.form.get("mensagem", "").strip()
    titulo = request.form.get("titulo", "").strip() or "KACU KEY"
    if mensagem:
        novo_id = int(get_setting("notification_id", "0") or "0") + 1
        set_setting("notification_id", str(novo_id))
        set_setting("notification_title", titulo)
        set_setting("notification_message", mensagem)
        set_setting("notification_sent_at", datetime.utcnow().isoformat() + "Z")
    return redirect("/painel-x7k9/dashboard#notificacao")


@app.route("/painel-x7k9/sair")
def admin_logout():
    session.pop("admin", None)
    return redirect("/painel-x7k9")


# ══════════════════════════════════════════════════════════════════════
# API XNX LOJA — catálogo de APKs + vendas automáticas
# ══════════════════════════════════════════════════════════════════════

@app.route("/api/apks", methods=["GET"])
def api_apks():
    """Endpoint que o XNX LOJA puxa o catálogo."""
    db = get_db()
    rows = db.execute("SELECT * FROM xnx_apks ORDER BY nome").fetchall()
    apks = []
    for r in rows:
        apks.append({
            "id": r["id"],
            "nome": r["nome"] or "",
            "versao": r["versao"] or "",
            "link_download": r["link_download"] or "",
            "imagem_url": r["imagem_url"] or "",
            "descricao": r["descricao"] or "",
            "categoria": r["categoria"] or "",
            "preco": float(r["preco"] or 0),
            "estoque": int(r["estoque"] or 0),
            "tamanho": r["tamanho"] or "",
            "pacote": r["pacote"] or "",
        })
    return jsonify({
        "status": "success",
        "loja": "XNX LOJA",
        "apks": apks,
    })


@app.route("/api/vendas", methods=["POST"])
def api_vendas():
    """Registra venda automática, gera chave de licença e baixa estoque."""
    data = request.get_json(silent=True) or {}
    apk_id = (data.get("apkId") or data.get("apk_id") or data.get("id") or "").strip()
    comprador = (data.get("comprador") or data.get("buyer") or "Cliente").strip()
    try:
        valor = float(data.get("valor") or data.get("price") or 0)
    except (TypeError, ValueError):
        valor = 0.0
    chave = (data.get("chaveLicenca") or data.get("license") or "").strip()

    db = get_db()
    found = db.execute("SELECT * FROM xnx_apks WHERE id = ?", (apk_id,)).fetchone() if apk_id else None
    apk_nome = found["nome"] if found else ""

    if found:
        estoque = int(found["estoque"] or 0)
        if estoque > 0:
            db.execute("UPDATE xnx_apks SET estoque = ? WHERE id = ?", (estoque - 1, apk_id))
        if not chave:
            chave = (
                "XNX-VIP-"
                + "".join(secrets.choice(string.digits) for _ in range(3))
                + "-"
                + "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(6))
            )

    db.execute(
        "INSERT INTO xnx_vendas (apk_id, apk_nome, comprador, valor, chave_licenca, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (apk_id, apk_nome, comprador, valor, chave, datetime.utcnow().isoformat() + "Z"),
    )
    db.commit()

    estoque_restante = None
    if found:
        row = db.execute("SELECT estoque FROM xnx_apks WHERE id = ?", (apk_id,)).fetchone()
        estoque_restante = int(row["estoque"]) if row else None

    return jsonify({
        "success": True,
        "message": "Venda registrada!",
        "chaveLicenca": chave,
        "estoqueRestante": estoque_restante,
    })


@app.route("/painel-x7k9/xnx-salvar", methods=["POST"])
def admin_xnx_salvar():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    action = request.form.get("action", "update")
    db = get_db()

    if action == "add":
        new_id = "apk_" + "".join(secrets.choice(string.digits) for _ in range(3))
        # garante id único
        while db.execute("SELECT 1 FROM xnx_apks WHERE id = ?", (new_id,)).fetchone():
            new_id = "apk_" + "".join(secrets.choice(string.digits) for _ in range(3))
        try:
            preco = float(request.form.get("preco") or 0)
        except ValueError:
            preco = 0.0
        try:
            estoque = int(request.form.get("estoque") or 0)
        except ValueError:
            estoque = 0
        db.execute(
            "INSERT INTO xnx_apks (id, nome, versao, link_download, imagem_url, descricao, categoria, preco, estoque, tamanho, pacote) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                new_id,
                (request.form.get("nome") or "").strip() or "Novo APK",
                (request.form.get("versao") or "1.0").strip(),
                (request.form.get("link_download") or "").strip(),
                (request.form.get("imagem_url") or "").strip(),
                (request.form.get("descricao") or "").strip(),
                (request.form.get("categoria") or "Games").strip(),
                preco,
                estoque,
                (request.form.get("tamanho") or "").strip(),
                (request.form.get("pacote") or "").strip(),
            ),
        )
        db.commit()
    elif action == "delete":
        apk_id = request.form.get("id", "").strip()
        if apk_id:
            db.execute("DELETE FROM xnx_apks WHERE id = ?", (apk_id,))
            db.commit()
    else:  # update
        apk_id = request.form.get("id", "").strip()
        if apk_id:
            try:
                preco = float(request.form.get("preco") or 0)
            except ValueError:
                preco = 0.0
            try:
                estoque = int(request.form.get("estoque") or 0)
            except ValueError:
                estoque = 0
            db.execute(
                "UPDATE xnx_apks SET nome=?, versao=?, link_download=?, imagem_url=?, descricao=?, "
                "categoria=?, preco=?, estoque=?, tamanho=?, pacote=? WHERE id=?",
                (
                    (request.form.get("nome") or "").strip(),
                    (request.form.get("versao") or "").strip(),
                    (request.form.get("link_download") or "").strip(),
                    (request.form.get("imagem_url") or "").strip(),
                    (request.form.get("descricao") or "").strip(),
                    (request.form.get("categoria") or "").strip(),
                    preco,
                    estoque,
                    (request.form.get("tamanho") or "").strip(),
                    (request.form.get("pacote") or "").strip(),
                    apk_id,
                ),
            )
            db.commit()
    return redirect("/painel-x7k9/dashboard#xnx")


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 7860)))
else:
    init_db()
