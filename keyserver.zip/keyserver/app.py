import os
import sqlite3
import secrets
import string
import requests
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, render_template, redirect, session, g, Response

app = Flask(__name__)


# ---------------------------------------------------------------
# CORS — permite que o site hospedado em outro endereço
# (por exemplo no GitHub Pages) chame esta API.
# ---------------------------------------------------------------
@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    return response


@app.route("/api/<path:_any>", methods=["OPTIONS"])
def cors_preflight(_any):
    return "", 204


# ---------------------------------------------------------------
# CONFIGURAÇÃO — troque estes valores antes de publicar
# ---------------------------------------------------------------
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "Troque#Esta1Senha")
app.secret_key = os.environ.get("SECRET_KEY", secrets.token_hex(16))

KEY_LENGTH_FREE = 10
KEY_LENGTH_VIP = 24
KEY_TTL_HOURS = 1
DB_PATH = os.path.join(os.path.dirname(__file__), "keys.db")

SOCIAL_LINKS = {
    "instagram": "https://www.instagram.com/rp_cris47",
    "whatsapp": "https://whatsapp.com/channel/0029VbCpyfeEgGfHP3DNvl1e",
    "telegram": "https://t.me/ggfpanel",
}

# ---------------------------------------------------------------
# BANCO DE DADOS
# ---------------------------------------------------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS keys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            tier TEXT NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)
    conn.commit()
    conn.close()


def get_setting(key, default=""):
    db = get_db()
    row = db.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(key, value):
    db = get_db()
    db.execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )
    db.commit()


def generate_code(length=KEY_LENGTH_FREE):
    alphabet = string.ascii_uppercase + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def cleanup_expired_keys():
    """Apaga de vez do banco qualquer senha que já passou da validade."""
    db = get_db()
    db.execute("DELETE FROM keys WHERE expires_at < ?", (datetime.utcnow().isoformat(),))
    db.commit()


def create_key(tier):
    db = get_db()
    length = KEY_LENGTH_VIP if tier == "vip" else KEY_LENGTH_FREE
    code = generate_code(length)
    now = datetime.utcnow()
    expires = now + timedelta(hours=KEY_TTL_HOURS)
    db.execute(
        "INSERT INTO keys (code, tier, created_at, expires_at, active) VALUES (?, ?, ?, ?, 1)",
        (code, tier, now.isoformat(), expires.isoformat()),
    )
    db.commit()
    return code, expires


# ---------------------------------------------------------------
# PÁGINAS PÚBLICAS
# ---------------------------------------------------------------
@app.route("/")
def home():
    return render_template("index.html", links=SOCIAL_LINKS, support_email=get_setting("support_email"))


@app.route("/termos")
def termos():
    return render_template("termos.html", support_email=get_setting("support_email"))


@app.route("/vip")
def vip_page():
    return render_template(
        "vip.html",
        telegram=SOCIAL_LINKS["telegram"],
        support_email=get_setting("support_email"),
    )


@app.route("/apk")
@app.route("/APK")
def apk_page():
    return render_template(
        "apk.html",
        version=get_setting("apk_version"),
        description=get_setting("apk_description"),
        link=get_setting("apk_link"),
    )


# ---------------------------------------------------------------
# API — GERAÇÃO E VALIDAÇÃO DE SENHAS
# ---------------------------------------------------------------
@app.route("/api/generate-free", methods=["POST"])
def api_generate_free():
    cleanup_expired_keys()
    code, expires = create_key("free")
    return jsonify({"code": code, "tier": "free", "expires_at": expires.isoformat() + "Z"})


@app.route("/api/generate-vip", methods=["POST"])
def api_generate_vip():
    # Passo futuro: só chega aqui depois que o pagamento Pix for confirmado.
    # Por enquanto, essa rota fica desativada no site público.
    return jsonify({"error": "Pagamento ainda não configurado. Gere a senha VIP pelo painel do administrador."}), 403


@app.route("/api/tts", methods=["POST"])
def api_tts():
    """
    O aplicativo manda a senha da pessoa + o texto que ela quer ouvir.
    Este servidor confere a senha, e só então chama a ElevenLabs usando
    a chave guardada aqui — a chave nunca aparece dentro do APK.
    """
    data = request.get_json(silent=True) or {}
    code = (data.get("code") or "").strip().upper()
    text = (data.get("text") or "").strip()

    if not code or not text:
        return jsonify({"error": "Envie 'code' e 'text'."}), 400

    db = get_db()
    row = db.execute("SELECT * FROM keys WHERE code = ?", (code,)).fetchone()
    if row is None:
        return jsonify({"error": "Senha não encontrada."}), 404
    if not row["active"]:
        return jsonify({"error": "Senha desativada."}), 403
    if datetime.utcnow() > datetime.fromisoformat(row["expires_at"]):
        return jsonify({"error": "Senha expirada."}), 403

    api_key = get_setting("elevenlabs_api_key")
    voice_id = get_setting("elevenlabs_voice_id")

    if not api_key or not voice_id:
        return jsonify({"error": "O administrador ainda não configurou a voz."}), 503

    try:
        resp = requests.post(
            f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
            headers={
                "xi-api-key": api_key,
                "Content-Type": "application/json",
                "Accept": "audio/mpeg",
            },
            json={
                "text": text,
                "model_id": "eleven_multilingual_v2",
            },
            timeout=30,
        )
    except requests.RequestException as e:
        return jsonify({"error": f"Falha ao contatar a ElevenLabs: {e}"}), 502

    if resp.status_code != 200:
        return jsonify({"error": "ElevenLabs recusou o pedido.", "details": resp.text}), 502

    return Response(resp.content, mimetype="audio/mpeg")


@app.route("/api/validate", methods=["POST"])
def api_validate():
    data = request.get_json(silent=True) or {}
    code = (data.get("code") or "").strip().upper()

    if not code:
        return jsonify({"valid": False, "reason": "Nenhuma senha enviada."}), 400

    db = get_db()
    row = db.execute("SELECT * FROM keys WHERE code = ?", (code,)).fetchone()

    if row is None:
        return jsonify({"valid": False, "reason": "Senha não encontrada."}), 404

    if not row["active"]:
        return jsonify({"valid": False, "reason": "Senha desativada."}), 403

    expires_at = datetime.fromisoformat(row["expires_at"])
    if datetime.utcnow() > expires_at:
        db.execute("DELETE FROM keys WHERE id = ?", (row["id"],))
        db.commit()
        return jsonify({"valid": False, "reason": "Senha expirada."}), 403

    return jsonify({
        "valid": True,
        "tier": row["tier"],
        "expires_at": row["expires_at"] + "Z",
    })


# ---------------------------------------------------------------
# PAINEL DO ADMINISTRADOR (escondido, protegido por senha)
# ---------------------------------------------------------------
@app.route("/painel-x7k9", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        senha = request.form.get("senha", "")
        if senha == ADMIN_PASSWORD:
            session["admin"] = True
            return redirect("/painel-x7k9/dashboard")
        return render_template("admin_login.html", erro="Senha incorreta.")
    return render_template("admin_login.html", erro=None)


@app.route("/painel-x7k9/dashboard")
def admin_dashboard():
    if not session.get("admin"):
        return redirect("/painel-x7k9")

    cleanup_expired_keys()
    db = get_db()
    rows = db.execute("SELECT * FROM keys ORDER BY id DESC").fetchall()
    now = datetime.utcnow()
    keys = []
    for r in rows:
        expires_at = datetime.fromisoformat(r["expires_at"])
        keys.append({
            "id": r["id"],
            "code": r["code"],
            "tier": r["tier"],
            "created_at": r["created_at"],
            "expires_at": r["expires_at"],
            "active": bool(r["active"]),
            "expired": now > expires_at,
        })

    elevenlabs_api_key = get_setting("elevenlabs_api_key")
    elevenlabs_voice_id = get_setting("elevenlabs_voice_id")
    # Mostra só o começo e o fim da chave, para conferência sem expor tudo na tela.
    api_key_preview = (
        elevenlabs_api_key[:4] + "…" + elevenlabs_api_key[-4:]
        if len(elevenlabs_api_key) > 8 else elevenlabs_api_key
    )

    return render_template(
        "admin_dashboard.html",
        keys=keys,
        api_key_preview=api_key_preview,
        has_api_key=bool(elevenlabs_api_key),
        voice_id=elevenlabs_voice_id,
        support_email=get_setting("support_email"),
        apk_version=get_setting("apk_version"),
        apk_description=get_setting("apk_description"),
        apk_link=get_setting("apk_link"),
    )


@app.route("/painel-x7k9/salvar-suporte", methods=["POST"])
def admin_salvar_suporte():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    email = request.form.get("support_email", "").strip()
    set_setting("support_email", email)
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/publicar-apk", methods=["POST"])
def admin_publicar_apk():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    set_setting("apk_link", request.form.get("apk_link", "").strip())
    set_setting("apk_version", request.form.get("apk_version", "").strip())
    set_setting("apk_description", request.form.get("apk_description", "").strip())
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/despublicar-apk", methods=["POST"])
def admin_despublicar_apk():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    set_setting("apk_link", "")
    set_setting("apk_version", "")
    set_setting("apk_description", "")
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/salvar-voz", methods=["POST"])
def admin_salvar_voz():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    api_key = request.form.get("elevenlabs_api_key", "").strip()
    voice_id = request.form.get("elevenlabs_voice_id", "").strip()
    if api_key:
        set_setting("elevenlabs_api_key", api_key)
    if voice_id:
        set_setting("elevenlabs_voice_id", voice_id)
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/gerar-vip", methods=["POST"])
def admin_gerar_vip():
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    create_key("vip")
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/desativar/<int:key_id>", methods=["POST"])
def admin_desativar(key_id):
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    db = get_db()
    db.execute("UPDATE keys SET active = 0 WHERE id = ?", (key_id,))
    db.commit()
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/apagar/<int:key_id>", methods=["POST"])
def admin_apagar(key_id):
    """Apaga a senha de vez do banco, diferente de só desativar."""
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    db = get_db()
    db.execute("DELETE FROM keys WHERE id = ?", (key_id,))
    db.commit()
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/limpar-expiradas", methods=["POST"])
def admin_limpar_expiradas():
    """Apaga de uma vez todas as senhas já expiradas."""
    if not session.get("admin"):
        return redirect("/painel-x7k9")
    cleanup_expired_keys()
    return redirect("/painel-x7k9/dashboard")


@app.route("/painel-x7k9/sair")
def admin_logout():
    session.pop("admin", None)
    return redirect("/painel-x7k9")


# ---------------------------------------------------------------
if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 7860)))
else:
    init_db()
